JBoss Fuse Features
===================
This module contains the Karaf feature `keycloak-fuse-quickstarts`, which is used by `server` module to install all the other Keycloak Fuse Quickstart applications into the JBoss Fuse server.
